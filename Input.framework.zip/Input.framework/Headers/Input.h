//
//  Input.h
//  Input
//
//  Created by LuzanovRoman on 22.01.2018.
//  Copyright © 2018 LuzanovRoman. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for Input.
FOUNDATION_EXPORT double InputVersionNumber;

//! Project version string for Input.
FOUNDATION_EXPORT const unsigned char InputVersionString[];

